import subprocess
import sys

subprocess.call(['./syntax_analyzer_rs', sys.argv[1]])